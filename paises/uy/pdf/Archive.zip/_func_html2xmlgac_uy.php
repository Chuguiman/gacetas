﻿<?php

require_once ("../../clases/_func_tranformar_gac_ext.php");

  
function desc_actaweb_uy($signo, $carpeta) {
	
	$ngac=$signo;
	$nacta = $signo.".html"; 
	$dirsolweb = "origen/".$nacta;
    echo "<br>".$dirsolweb."<br>";
    
	
    if (trim($nacta) != "") {
        //Contenido de la página        
        $cadsw = ret_txtfile2($dirsolweb);
		if (mb_detect_encoding($cadsw, 'ISO-8859-1', TRUE) !== 'UTF-8') {//ISO-8859-1
			$cadsw = utf8_encode($cadsw);
		}
		
		$cadsw = strip_tags($cadsw,"<b><br>");
		$cadsw = trim($cadsw);
		$cadsw = preg_replace('/\s+/', ' ', $cadsw);
		$cadsw = str_replace("<b>", "<td>", $cadsw);
		$cadsw = str_replace("</b>", "</td>", $cadsw);
		$cadsw = str_replace("<td> ", "<td>", $cadsw);
		$cadsw = str_replace(" </td>", "</td>", $cadsw);
		$cadsw = str_replace("<br>", "</td><td>", $cadsw);
		$cadsw = str_replace("BOLETIN DE LA PROPIEDAD INDUSTRIAL Nº", "</td><td>BOLETIN DE LA PROPIEDAD INDUSTRIAL <br>", $cadsw);
		$cadsw = str_replace("</td></td><td>", "</td><td>", $cadsw);
		$cadsw = str_replace("<td>ÍNDICE POR TITULARES DE MARCAS</td><td>", "", $cadsw);
		$cadsw = str_replace("<td></td><td>", "", $cadsw);
		$cadsw = str_replace("<td> <td>N° Exp Marca</td><td>", "<td> Exp </td><td> Marca </td><td>", $cadsw);
		$cadsw = str_replace("<td>   <td>Titular</td>", "<td> Titular </td>", $cadsw);
		$cadsw = str_replace("</td><td> </td><td>", "", $cadsw);
		$cadsw = preg_replace("/<td> ([0-9]{6,})*/", "<td> EXP: </td><td> $1 </td><td> DENOMINACION: </td><td>", $cadsw);
		$cadsw = str_replace("<td> EXP: </td><td>  </td><td> DENOMINACION: </td>", "", $cadsw);
		$cadsw = str_replace("ÍNDICE POR TITULARES DE FRASES PUBLICITARIAS", "</td><td>ÍNDICE POR TITULARES DE FRASES PUBLICITARIAS", $cadsw);
		$cadsw = preg_replace("/BOLETIN DE LA PROPIEDAD INDUSTRIAL[[:space:]]*([^<br>]*<br>)/", "</td>", $cadsw);
		$cadsw = ereg_replace("</td>*([^<td>]*)", " </td>", $cadsw);
		$cadsw = str_replace(" (mixta) ", " </td><td> TIPO MARCA: </td><td> MIXTA </td><td> TITULAR: </td><td> ", $cadsw);
		$cadsw = str_replace("(mixta) ", " </td><td> TIPO MARCA: </td><td> MIXTA </td><td> TITULAR: </td><td> ", $cadsw);
		$cadsw = str_replace("(figurativa) ", " FIGURATIVA </td><td> TIPO MARCA: </td><td> FIGURATIVA </td><td> TITULAR: </td><td> ", $cadsw);
		$cadsw = str_replace("(tridimensional) ", "  </td><td> TIPO MARCA: </td><td> TRIDIMENSIONAL </td><td> TITULAR: </td><td> ", $cadsw);
		
		//Retornar Archivo
		$txtfile  = $signo.".txt";
		$txtfile2 = $signo.".xml";
		
        save_txtinfile($carpeta . "/" . $txtfile, utf8_decode($cadsw));
		
		//Limpia
        $gestor = @fopen($carpeta . "/" . $txtfile, "r");
        if ($gestor) {
            while (!feof($gestor)) {
                $bufer.= fgetss($gestor, 4096, '<td>');
            }
            fclose($gestor);
        }
		
		
		$bufer = preg_replace('/\s+/', ' ', $bufer);
		$bufer = preg_replace("/<tr[[:space:]]*([^>]*>)/", "<tr>", $bufer);
        $bufer = preg_replace("/<td[[:space:]]*([^>]*>)/", "<td>\n", $bufer);        
        $bufer = preg_replace("/\/\*[[:space:]]*([^\*\/]\*\/)/", "", $bufer);
        $bufer = preg_replace("/^[[:space:]]*([^<]*<)/", "<", $bufer);
        $bufer = preg_replace('/\s(?=\s)/', '', $bufer);
        $bufer = preg_replace('/[\n\r\t]/', ' ', $bufer);  
        $bufer = preg_replace('/\s(?=\s)/', '', $bufer);
        $bufer = preg_replace('/[\n\r\t]/', ' ', $bufer);
		
		$bufer = str_replace(" </td>> ", " </td><td> ", $bufer);
		$bufer = str_replace("<td> BOLETIN DE LA PROPIEDAD INDUSTRIAL 182 - 2014", "<td> BOLETIN DE LA PROPIEDAD INDUSTRIAL 182 - 2014 </td>", $bufer);
		$bufer = str_replace("</td> </td><td>", " </td><td>", $bufer);
		$bufer = str_replace(" </td>d> ", " </td><td> ", $bufer);
		$bufer = str_replace("BOLETIN DE LA PROPIEDAD INDUSTRIAL 182 - 2014", "</td><td>", $bufer);
		$bufer = str_replace("<td> Titular</td>", "", $bufer);
		$bufer = str_replace("<td> Exp </td>", "", $bufer);
		$bufer = str_replace("<td> Marca </td>", "", $bufer);
		$bufer = str_replace("<td> Titular </td>", "", $bufer);
		$bufer = str_replace("<td>  </td>", "", $bufer);
		$bufer = str_replace("<td></td>", "", $bufer);
		$bufer = str_replace("<td> </td>", "", $bufer);
		$bufer = str_replace("<td></td>", "", $bufer);
		$bufer = str_replace(" </td>>", " </td><td> ", $bufer);
		$bufer = str_replace("  </td><td> <td> ", " </td><td> ", $bufer);
		$bufer = str_replace(" </td>d>", " </td><td> ", $bufer);
		$bufer = str_replace(" </td><td> <td> ", " </td><td> ", $bufer);
		$bufer = str_replace("", "", $bufer);
		$bufer = str_replace("", "", $bufer);
		
		
		


		//Inicio de XML Guardo y elimina txt
		$bufer = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<pag>\n<td>" . $bufer . "</td>\n</pag>";
        if (mb_detect_encoding($bufer, 'UTF-8', TRUE) !== 'UTF-8') {
			$bufer = utf8_encode($bufer);
		}
		
		$bufer = str_replace("<td> ÍNDICE POR TITULARES DE FRASES PUBLICITARIAS</td>", "</td>", $bufer);
		$bufer = str_replace("</td>td>", " </td><td> ", $bufer);
		$bufer = str_replace(" td><td> ", " </td><td> ", $bufer);
		$bufer = str_replace(" ><td> ", " </td><td> ", $bufer);
		$bufer = str_replace("<td> /td>", "<td> </td>", $bufer);
		$bufer = str_replace(" d><td> ", " </td><td> ", $bufer);
		$bufer = str_replace(" /td><td> ", " </td><td> ", $bufer);
		
		save_txtinfile($carpeta . "/" . $txtfile2, $bufer);
        unlink($carpeta . "/" . $txtfile);  
        
		//Contenido del archivo
		$xmlstr = ret_txtfile1($carpeta."/".$txtfile2);
		
		//Lectura de XML
		$ant = $act = "";
		$xml = new SimpleXMLElement($xmlstr);
		$datosbasicos = array();
		$datosgenerales = array();
		$j = -1;
		foreach ($xml->td as $td) {
			$ant2= $ant;
			$ant = $act;
			$act = "";
			$td = trim($td);
			switch ($td) {
				case "EXP:":
					$act = "exp";
					if($j>=0){
						$datosgenerales[$j]=$datosbasicos;
						$datosbasicos = array();
						
					}
					$j++;
					break;
				case "DENOMINACION:":
					$act = "denominacion";
					break;
				case "TIPO MARCA:":
					$act = "tipo_marca";
					break;
				case "TITULAR:":
					$act = "";
					break;	
				default:
					if ($act == "" & $ant != "") {
						$datosbasicos[$ant] = trim($td);
					}elseif ($act == "" & $ant == ""){
						$ant = $ant2;
						$datosbasicos[$ant].=" ". trim($td);
					}
					break;
			}

			
		}
		
		foreach ($datosgenerales as $datoadato) {
			
			//echo "<br>==========================================";
			/*echo "<br><b>EXP:</b> ".*/$expediente=substr(($datoadato["exp"]), 0, 7);//14
			/*echo "<br><b>DENO:</b> ".*/$denominacion=$datoadato["denominacion"];
			/*echo "<br><b>TMA:</b> ".*/$tipomarca=$datoadato["tipo_marca"];
			
			add_marca($np, utf8_decode($denominacion),  utf8_decode($tipo_denomi),  utf8_decode($tipomarca), $expediente, $fecha_solicitud, utf8_decode($titular),  utf8_decode($direccion), utf8_decode($domicilio),  utf8_decode($apoderado), $dir_apo, $clases, $ngac, $fecha_publicacion, $plazo_opo, utf8_decode($prioridad), utf8_decode($prodyservs));	
			
			$sql1 = "DELETE FROM `sam_precarga_gac_exterior` WHERE (`tipomarca`='');";
			mysql_query ($sql1);
			
			$sql2 = "UPDATE `sam_precarga_gac_exterior` SET `denominacion`=NULL WHERE (`tipomarca`='FIGURATIVA');";
			mysql_query ($sql2);
			
		}	
		
	}
	unlink($carpeta . "/" . $txtfile2);	
	
	transforma_gac_uy ($signo, $carpeta);
}

function transforma_gac_uy ($signo, $carpeta) {
	
	$ngac=$signo;
	$nacta = $signo."m.html"; 
	$dirsolweb = "origen/".$nacta;
    echo "<br>".$dirsolweb."<br>";
    
	
    if (trim($nacta) != "") {
        //Contenido de la página        
        $cadsw = ret_txtfile2($dirsolweb);
		if (mb_detect_encoding($cadsw, 'ISO-8859-1', TRUE) !== 'UTF-8') {//ISO-8859-1
			$cadsw = utf8_encode($cadsw);
		}
		
		$cadsw = strip_tags($cadsw,"<b><br>");
		$cadsw = trim($cadsw);
		$cadsw = str_replace("República Oriental del Uruguay", "", $cadsw);
		$cadsw = str_replace("BOLETIN DE LA PROPIEDAD INDUSTRIAL Nº", "<br>", $cadsw);
		$cadsw = str_replace(" <br>(210)  <b>", "<td> EXP: </td> <td> ", $cadsw);
		$cadsw = str_replace("</b>", " </td>", $cadsw);
		$cadsw = str_replace("(540) <br>", "", $cadsw);
		$cadsw = str_replace("(730) <b>", "<td> TITULAR: </td> <td> ", $cadsw);
		$cadsw = str_replace(" </td>; ", " </td> <td> DOMICILIO: </td> <td> ", $cadsw);
		$cadsw = str_replace("(220) ", "<td> FECHA SOLICITUD: </td> <td> ", $cadsw);
		$cadsw = str_replace("(220) ", "<td> FECHA SOLICITUD: </td> <td> ", $cadsw);
		$cadsw = str_replace("<br>", "</td> <td>", $cadsw);
		$cadsw = str_replace("(511) <b>", "<td> CLASES: </td> <td> ", $cadsw);
		$cadsw = str_replace("(511)  <b>", "<td> CLASES: </td> <td> ", $cadsw);
		$cadsw = str_replace("(740) ", "<td> COD_APO: </td> <td> ", $cadsw);
		$cadsw = preg_replace('/\s+/', ' ', $cadsw);
		$cadsw = str_replace("<b>", "", $cadsw);
		$cadsw = str_replace("(591) ", " COLOR: </td> <td> ", $cadsw);
		$cadsw = str_replace("(300) ", " PRIORIDAD: </td> <td> ", $cadsw);
		$cadsw = str_replace(" <td>  </td></td> <td> ", "", $cadsw);
		$cadsw = str_replace(" <td> </td> <td><td> ", "<td> ", $cadsw);
		$cadsw = str_replace(" </td> </td> <td> <td> ", " </td> <td> ", $cadsw);
		$cadsw = str_replace(" </td> <td> <td> ", " </td> <td> ", $cadsw);
		$cadsw = str_replace(" <td> </td> ", "", $cadsw);
		$cadsw = str_replace(" </td></td> <td> ", " </td> <td> ", $cadsw);
		$cadsw = str_replace(" </td> <td> <td> EXP: </td>", " </td> <td> EXP: </td>", $cadsw);
		$cadsw = str_replace(" </td><td> </td> <td> ", " </td> <td> DENOMINACION: </td> <td> ", $cadsw);
		$cadsw = str_replace("</td></td><td> </td> <td>", "</td><td> DENOMINACION: </td><td>", $cadsw);
		$cadsw = str_replace(" </td></td><td> ", " </td><td> ", $cadsw);
		$cadsw = str_replace("'", "\'", $cadsw);
		
			
		//Retornar Archivo
		$txtfile  = $signo.".txt";
		$txtfile2 = $signo.".xml";
		
        save_txtinfile($carpeta . "/" . $txtfile, utf8_decode($cadsw));
		
		//Limpia
        $gestor = @fopen($carpeta . "/" . $txtfile, "r");
        if ($gestor) {
            while (!feof($gestor)) {
                $bufer.= fgetss($gestor, 4096, '<td>');
            }
            fclose($gestor);
        }
		
		
		$bufer = str_replace("</td><td> </td></td> <td>(210)", "</td> <td> EXP: </td> <td> ", $bufer);
		$bufer = str_replace(" </td>g", " </td> <td> g", $bufer);
		$bufer = str_replace("c-</td>7", "C-7", $bufer);
		$bufer = str_replace(" </td></td><td>(210)  ", "</td> <td> EXP: </td> <td> ", $bufer);
		$bufer = str_replace(": </td>C 65", ": C 65", $bufer);
		$bufer = str_replace("'", "\'", $bufer);

		//Inicio de XML Guardo y elimina txt
		$bufer = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<pag>\n<td>" . $bufer . "</td>\n</pag>";
        if (mb_detect_encoding($bufer, 'UTF-8', TRUE) !== 'UTF-8') {
			$bufer = utf8_encode($bufer);
		}
		
		$bufer = str_replace("</td> >", " </td> <td>", $bufer);
		$bufer = str_replace(" d> <td> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" /td> <td> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" </td> td> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" > <td> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" td> <td> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" </td> d> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" </td> </td> <td> ", " </td> <td> ", $bufer);
		$bufer = str_replace(" </td></td><td>", " </td> <td> ", $bufer);
		$bufer = str_replace(" </td></td> ", " </td> ", $bufer);
		$bufer = str_replace("", "", $bufer);
		
		save_txtinfile($carpeta . "/" . $txtfile2, $bufer);
        unlink($carpeta . "/" . $txtfile);  
        
		//Contenido del archivo
		$xmlstr = ret_txtfile1($carpeta."/".$txtfile2);
		
		//Lectura de XML
		$ant = $act = "";
		$xml = new SimpleXMLElement($xmlstr);
		$datosbasicos = array();
		$datosgenerales = array();
		$j = -1;
		foreach ($xml->td as $td) {
			$ant2= $ant;
			$ant = $act;
			$act = "";
			$td = trim($td);
			switch ($td) {
				case "EXP:":
					$act = "exp";
					if($j>=0){
						$datosgenerales[$j]=$datosbasicos;
						$datosbasicos = array();
						
					}
					$j++;
					break;
				case "TITULAR:":
					$act = "titular";
					break;
				case "DOMICILIO:":
					$act = "domicilio";
					break;
				case "FECHA SOLICITUD:":
					$act = "fecha_solicitud";
					break;
				case "CLASES:":
					$act = "clases";
					break;
				case "COD_APO:":
					$act = "apoderado";
					break;
				case "COLOR:":
					$act = "info";
					break;
				case "DENOMINACION:":
					$act = "denominacion2";
					break;
				case "PRIORIDAD:":
					$act = "prioridad";
					break;		
				default:
					if ($act == "" & $ant != "") {
						$datosbasicos[$ant] = trim($td);
					}elseif ($act == "" & $ant == ""){
						$ant = $ant2;
						$datosbasicos[$ant].=" ". trim($td);
					}
					break;
			}

			
		}

		foreach ($datosgenerales as $datoadato) {
			//echo "<br>==========================================";
			/*echo "<br><b>EXP:</b> ".*/$expediente=substr(($datoadato["exp"]), 0, 7);
			/*echo "<br><b>CL:</b> ".*/$clases = $datoadato["clases"];
								   $clases = str_replace("(S/D)", "", $clases);
			/*echo "<br><b>APO:</b> ".*/$apoderado=$datoadato["apoderado"];
			/*echo "<br><b>TIT:</b> ".*/$titular=$datoadato["titular"];
			/*echo "<br><b>DOM:</b> ".*/$domicilio=$datoadato["domicilio"];
			/*echo "<br><b>DENO:</b> ".*/$denominacion=$datoadato["denominacion2"];
			/*echo "<br><b>FSO:</b> ".*/substr(($fecha_solicitud=$datoadato["fecha_solicitud"]), 0, 14);
			/*echo "<br><b>INFO:</b> ".*/$info=$datoadato["info"];
			/*echo "<br><b>PRI:</b> ".*/$prioridad=$datoadato["prioridad"];
			
			
			$sql3 = "SELECT a.`expediente` AS X FROM `sam_precarga_gac_exterior` AS a WHERE a.`expediente` = '$expediente';";
			$rsql3 = mysql_query ($sql3);
				
			if(mysql_num_rows($rsql3)>0){
				$sql2 = "UPDATE `sam_precarga_gac_exterior` SET `fecha_solicitud`='$fecha_solicitud', `titular`='$titular', `domicilio`='$domicilio', `apoderado`='$apoderado', `clases`='$clases' WHERE (`expediente`='$expediente');";
				mysql_query (utf8_decode($sql2));
			}else{
				add_marca($np, utf8_decode($denominacion),  utf8_decode($tipo_denomi),  'DENOMINATIVA', $expediente, $fecha_solicitud, utf8_decode($titular),  utf8_decode($direccion), utf8_decode($domicilio),  utf8_decode($apoderado), $dir_apo, $clases, $ngac, $fecha_publicacion, $plazo_opo, utf8_decode($prioridad), utf8_decode($prodyservs));
			}
			
			$sql4 = "SELECT a.apoderado as X FROM sam_precarga_gac_exterior AS x , apoderados_uy AS a WHERE x.apoderado = a.cod_apo";
			$rsql4 = mysql_query ($sql4);
			
			if(mysql_num_rows($rsql4)>0){
				$nom_apo=mysql_result($rsql4,0,"X");
				$sql5 = "UPDATE `sam_precarga_gac_exterior` SET `apoderado` = '$nom_apo' WHERE (`expediente`='$expediente');";
				mysql_query ($sql5);
			}else{
				
			}
			
			$sql6 = "UPDATE `sam_precarga_gac_exterior` SET `clases`= REPLACE (`clases`, ' y ', ', ');";
			$rsql6 = mysql_query ($sql6);
		}	
	}
	unlink($carpeta . "/" . $txtfile2);	
	
}
?>