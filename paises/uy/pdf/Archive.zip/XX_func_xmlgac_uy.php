﻿<?php

	require_once ("../../clases/_func_tranformar_gac_ext.php");

	function gacxml2_uy ($ngac, $fechapub) {
		
		$plazo_opo = date('Y-m-d',strtotime('+30 days', strtotime($fechapub)));
		$archivo1 = "origen/".$ngac.".xml";

		//Abre Archivo de lista de Denominaciones para Lectura
	    $gestor = fopen($archivo1, "rb");
	    $contenido = stream_get_contents($gestor);
	    fclose($gestor); 

	    //Expresiones Regulares 1 (limpia Texto)
	    $patrones[0] = "/<page(.*?)>/";
	    $patrones[1] = "#</page>#";
	    $patrones[2] = "/<fontspec(.*?)>/";
	    $patrones[3] = "/<text (.*?)>/";
	    $patrones[4] = "/<i>/";
	    $patrones[5] = "/<b>/";
	    $patrones[6] = "/<text>P(.*?)gina:(.*?)>/";    
	    $patrones[7] = "/\s+/";//Quita Doble espacio
	    $patrones[8] = "#> <#";
	    $patrones[9]= "/> \(/";
	    $patrones[10]= "# </i>|</i>#";
	    $patrones[11]= "# </text>#";
	    $patrones[12]= "# </b>|</b>#";
	    $patrones[13] = "/<text> /";
	    $patrones[14] = "#<text>\r</text>#";
	    $patrones[15] = "/<text>(\d{6})/";
	    $patrones[16] = "/BOLETIN DE LA PROPIEDAD INDUSTRIAL/";

	    	    
	    array_push($patrones, "/\s+/","#> <#");
	    $reemplazos=array("","","","<text>","","", ""," ",">\r<",">(", "", "</text>","","<text>","","<text>EXP:</text>\r<text>$1</text>\r<text>DENOMI:</text>\r<text>",
	    					"</text>\r<text>XXX:</text>\r<text>");
	    
	    array_push($reemplazos, " ",">\r<");    
	    $contenido = preg_replace($patrones, $reemplazos, $contenido);

	    $ant = $act = "";
	    $xml = new SimpleXMLElement($contenido);
				
		$datosbasicos = array();
		$datosgenerales = array();
		$j = 0;
	    
	    foreach ($xml->text as $texto) {        
	        $ant2= $ant;
			$ant = $act;
			$act = "";      
	        $texto=trim($texto);
	        //echo $texto."\n";
	        switch ($texto) {
				case "EXP:":
				$act = "exp";
					if($j>=0){
						$datosgenerales[$j]=$datosbasicos;
						$datosbasicos = array();
					}
					$j++;
					break;
				case "DENOMI:":
					$act = "denomi";
					break;
				case "XXX:":
					$act = "bas";
					break;			
											
				default:
					if ($act =="" & $ant !="") {
						$datosbasicos[$ant] = trim($texto);
					}elseif ($act =="" & $ant =="") {
						$ant = $ant2;
						$datosbasicos[$ant].=" ". trim($texto);
					}
					break;	
			}		

		}
		/*echo "<pre>\n";
		var_dump($datosgenerales);*/
		
		/*echo "<pre>\n";
		print_r($datosgenerales);	*/

		foreach ($datosgenerales as $datoadato) {
			
			$expediente = substr(($datoadato["exp"]), 0, 6);
			if (!$expediente=="") {
				add_marca($np, utf8_decode($denominacion),  utf8_decode($signo),  utf8_decode($tipomarca), trim($expediente), $fecha_pres, utf8_decode($titular),  utf8_decode($direccion), utf8_decode($domicilio),  utf8_decode($apoderado), $dir_apo, $clases, $ngac, $fechapub, $plazo_opo, utf8_decode($prioridad), utf8_decode($prodyservs));	
			}
			
			
		}		
		echo "OK<br>";

		$conn=mysql_connect('localhost','root','');
		mysql_select_db('gacetas',$conn);
		
		$sql="Select trim(a.expediente) AS X From sam_precarga_gac_exterior AS a";
		$rsql=mysql_query($sql);
		
		if(mysql_num_rows($rsql)>0){
			for($i=0; $i<mysql_num_rows($rsql); $i++){
				
				$numsigno=mysql_result($rsql, $i, "X");
				$numsigno*1;
				$dirsolweb="http://190.64.2.103:8090/IpasWebQuery/markEditAction.jsp?fileId=MA/M/0001/00".$numsigno."";
				echo $dirsolweb."<br>";

				if ($dirsolweb!="") {
					$carpeta = "origen/";
					$cadsw = ret_txtfile2($dirsolweb);       
			        $cadsw = reemplazaracentoshtml($cadsw);
			        $cadsw = corregir_otrosacentos($cadsw);
			        $cadsw = preg_replace("/<head[^>]*?>.*?<\/head>/si", "", $cadsw); //Elimina Contenido del HEAD
			        $cadsw = str_replace("<?", "", $cadsw);
			        $cadsw = str_replace("?>", "", $cadsw);

			        //Retornar Archivo
			        $txtfile  = $numsigno.".txt";
			        $txtfile2 = $numsigno.".xml";
			        save_txtinfile($carpeta.$txtfile, utf8_encode($cadsw));
			        //Limpia
			        $gestor = @fopen($carpeta.$txtfile, "r");
			        if ($gestor) {
			            while (!feof($gestor)) {
			                $bufer.= fgetss($gestor, 4096, "<td><th>");
			            }
			            fclose($gestor);
			        }
			        echo $bufer;	

				}

    		}
    	}		

	}


?>